def add_rwo_numbers(a, b):
    return a + b